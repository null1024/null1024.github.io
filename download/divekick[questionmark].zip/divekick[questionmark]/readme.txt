"divekick?" - 2013 null1024

about:
I wrote this a decade ago, shortly before Divekick <https://store.steampowered.com/app/244730/Divekick/> came out.
It isn't really made for modern machines, as I developed it in Game Maker 5.3.
It runs fine on my laptop with Windows 10, but I do remember a period of time where it didn't.
The game requires a second player, there is no CPU opponent to fight.

files:
* divekick[questionmark].exe - the game itself
* divekick[questionmark].gmd - the Game Maker 5 project file

controls:
* q - p1 dive
* o - p2 dive
* w - p1 kick
* p - p2 kick
* esc - exit game
* f1 - show help
* f4 - toggle fullscreen

Hope you enjoy.
