"use strict";
/*
	WILD-BREAKER.ex [rev1] -- 2017, 2022 null1024
	original version made for Battle of the Bits' 2nd game jam
    licensed under https://creativecommons.org/licenses/by-nc-sa/3.0/
    
    todo: add pausing (started it, didn't finish, shouldn't take any effort but I don't feel like writing more code right now), add multiple enemy types (so, add a sub-enemy field? enemies that go really quick, enemies that come in slow from the sides, etc?), add bombs (important!), fix scoring (might tweak a bit, seems good maybe now?), add endings, total rewrite of depth handling so I can fix the collision bug (REALLY IMPORTANT and I haven't started on it), add a grace period after losing a life, fix the weird color bug that's probably related to some out of bounds access or something (the color seems to be set based the bottom-right cell, maybe it's just using that because it's the last time the color changes), adjust starting difficulty a little to accommodate the addition of bombs and to get things a bit more exciting, add story scroller on title screen, lower difficulty curve increase later on, refactor (this mightn't happen for a while)
    
    did quite a bit already, but I keep adding stuff to the list and it's become terribly long
    
    firefox was giving me hideous, erratic performance issues and it just turned out that I needed to reboot my machine
    got a crazy speedup when I turned off color because I probably shouldn't be changing the color so much (but seriously, that doesn't need to be so slow), so disabling color is a toggle now just in case
    might make the starfield a toggle but I dunno
    supposedly, really old versions of Firefox actually do have issues with loads of font color changes on a canvas
*/


//variables
//a lot of these are actually set over in gameInit, so go check there if need be
var color_on = true; //color toggle
var pf_w=80; //playfield size
var pf_h=25;
var pf_cx=Math.floor(pf_w/2); //middle of playfield
var pf_cy=Math.floor(pf_h/2);
var obj_max=64; //total size of object list, we don't actually ever approach 64 though, but it's good to have the extra room and it's far from what's slowing this down
var shot_max=3;
var shot_count=0;
var enemy_timer_max=30; //max frames needed to spawn a new enemy
var enemy_timer_increase_max=4; //time needed to lower the above
var enemy_timer_increase=enemy_timer_increase_max;
var enemy_timer=enemy_timer_max;
var lives; //lives remaining, game over when at -1, not at 0
var bombs; //bomb stock, max of 5
var score=0;
var hiscore=new Array(3);
hiscore.fill(158);
var lastscore=0; //score from the most recent game over
var prevlastscore=0; //score from the penultimate game over
var c; //canvas
var ctx; //context
var ch_w; //width of characters, can change based on font
var ch_h=16; //font is guaranteed to be 12px tall
var disp_font = ch_h+"px monospace"; //set the font
var objs = new Array(obj_max); //list of all game objects
objs.fill("none"); //a non-object/unused object is either the string "none" or a wb_Object with type==="none"
var disp = new Array(pf_w*pf_h); //holds each element on the screen
var disp_col = new Array(pf_w*pf_h); //holds the color of each element on screen
var fg_color = "#ddd"; //default color
disp_col.fill(fg_color);
var bg_color = "#222"; //color to fill in
var state = 0; //=0 for title screen, >0 for in-game, <0 for debug
var lastKeyPressed="NONE!"; //kind of debug stuff
var lastKeyReleased="NONE!";
var y_coeff = 0.6; //multiply player y movement/friction against this
var snd_shot; //audio variables
var snd_explosion;
var snd_enemyshot;
var snd_music; //todo: add more music
var starfield=new Array(25); //cool bg effect to make it seem more like you're actually going through space (well, sub-space)
var score_message; //what message to show if you got a high score
var score_message_color; //what color to display it in
var rand_color = new Array("2","3","4","5","5","6","7"); //bag of intensities for the stars

function setScoreMessage(msg, color) {
    score_message=msg;
    score_message_color=color;
}

//wb_Star -- one of the stars in the starfield
function wb_Star() {
    this.show=0; //count in frames since being (re)spawned
    this.x=pf_cx;
    this.y=pf_cy;
    this.xd=Math.random()*2-1;
    this.yd=Math.random()*2-1;
    //generate a random star color
    this.color="#"+rand_color[Math.floor(Math.random()*rand_color.length)]+rand_color[Math.floor(Math.random()*rand_color.length)]+rand_color[Math.floor(Math.random()*rand_color.length)];
    this.applyAndDraw = function() {
        this.show++;
        this.x+=this.xd;
        this.y+=this.yd;
        this.xd*=1.14;
        this.yd*=1.08;
        //reposition when off-screen
        if (Math.floor(this.x) < 0 || Math.floor(this.y) < 0 || Math.floor(this.x) >= pf_w || Math.floor(this.y) >= pf_h) {
            //this.active=true;
            this.x=pf_cx;
            this.y=pf_cy;
            this.xd=Math.random()*2-1;
            this.yd=Math.random()*2-1;
            this.show=0;
        }
        //draw
        if (this.show > 5) {
            var chr="*";
            if (!color_on) { chr="."; } //use less distracting character when color is off since the colors are what allowed the star to not be obnoxious
            sd_c(Math.floor(this.x),Math.floor(this.y),chr,this.color);
        }
    };
}

//wb_Sprite -- text graphics data, composed of the size, origin, and data in block format
function wb_Sprite(w,h,cx,cy,data,color) {
    this.w=w;
    this.h=h;
    this.cx=cx;
    this.cy=cy;
    this.data=data;
    this.color=color;
}

//wb_Object -- something in the game
function wb_Object(x,y,sprite,depth) {
    this.type="none";
    this.x=x;
    this.y=y;
    this.sprite=sprite;
    this.depth=depth;
    this.subdepth=0; //goes from 0-99, adjust which depth level you're at based on this -- todo: make it go from 0-499
    this.draw = function() {
        drawSprite(this.x,this.y,this.sprite);
    };
    this.apply = function() {}; //override me
    this.remove = function() { //delete the object
        this.type="none";
    };
}

//handleZoom -- adjust the zoom level of an object based on its subdepth
//todo: rewrite
function handleZoom(obj) {
    if (obj.subdepth < 0) {
        while (obj.subdepth < 0) {
            obj.depth--;
            obj.subdepth+=99;
        }
    }
    else if (obj.subdepth >= 100) {
        while (obj.subdepth >=100) {
            obj.depth++;
            obj.subdepth-=100;
        }
        
    }
    if (obj.depth > 3 || obj.depth < 0) {
        if (obj.type=="enemy") {
            player.miss=true;
            lives--;
            snd_enemyshot.cloneNode(false).play();
        }
        obj.remove();
    }
}

//objectExists -- if the object is either uninitialized or 
function objectExists(obj) {
    if (obj==="none" || obj.type === "none") {
        return false;
    }
    return true;
}

//objectCollide -- check two colliding objects at given depth
//todo: total rewrite, gonna branch the code off once I start work on this
function objectCollide(obj1,obj2) {
    var slop = 20;
    if (!objectExists(obj1) || !objectExists(obj2)) {
        return false;
    }
    //todo: handle player collisions (stun player when hit?)
    //slightly more robust collision check, although you WILL still have near-misses by the edges
    if (obj1.depth !== obj2.depth) {
        return false;
        /* dirty kludge that probably didn't work, I didn't do the math for it at all so I'm just leaving it out until I rewrite depth entirely
        if (Math.abs(obj1.depth-obj2.depth) !== 1) { //can only be one apart
            return false;
        }
        if (obj1.depth > obj2.depth) { //obj1 is behind
            if (obj1.subdepth < 100-slop || obj2.subdepth >= slop) {
                return false;
            }
        } else { //obj2 is behind
            if (obj2.subdepth < 100-slop || obj1.subdepth >= slop) {
                return false;
            }
        }
        */
    }
    //these temp vars are strictly for readability
    var x1 = obj1.x-obj1.sprite.cx;
    var x2 = obj2.x-obj2.sprite.cx;
    var w1 = obj1.sprite.w;
    var w2 = obj2.sprite.w;
    var y1 = obj1.y-obj1.sprite.cy;
    var y2 = obj2.y-obj2.sprite.cy;
    var h1= obj1.sprite.h;
    var h2= obj2.sprite.h;
    if (x1<x2+w2 && x1+w1>x2 && y1<y2+h2 && y1+h1>y2) {
        return true;
    }
    return false;
}

//objectCollideType -- check an object against those of a given type
function objectCollideType(obj1,type) {
    for (var ii=0; ii < obj_max; ii++) {
        //ignore it if it's the very same object or it doesn't exist
        if (!objectExists(objs[ii]) ||objs[ii] === obj1) {
            continue;
        }
        //if we are colliding, then we're good
        if (objectCollide(obj1,objs[ii]) && objs[ii].type == type) {
            return objs[ii];
        }
    }
    return "none";
}

//shotApply -- things to do when shots happen
function shotApply() {
    this.subdepth+=15;
    handleZoom(this);
    if (this.depth >=0 && this.depth <=3) {
        this.sprite=player_shot[this.depth];
    }
    //check if we're hitting an enemy
    var collide_target = objectCollideType(this,"enemy");
    if (collide_target !== "none") {
        collide_target.remove(); //todo: transform it into an explosion
        this.remove();
        snd_explosion.cloneNode(false).play(); //play sound
        switch (this.depth) { //this is going to get changed anyway, but hey
            case 0:
                score+=750;
            break
            case 1:
                score+=875;
            break
            case 2:
                score+=1000;
            break
            case 3:
                score+=1230;
            break
        }
    }
    //remove from the counter if we stopped existing during all this
    //if something else ever kills a player shot, remember to make it lower shot_count
    if (this.type == "none") {
        shot_count--;
    }
}

//enemyApply -- things to do when enemies happen
//todo: add dx/dy variables, or maybe a target point on screen variable
function enemyApply() {
    this.subdepth-=8;
    handleZoom(this);
    this.x+=this.xd;
    this.y+=this.yd;
    if (this.depth >=0 && this.depth <=3) {
        this.sprite=enemy_spr[this.depth];
    }
}

//addObject -- puts something into the game, like a shot or an enemy
function addObject(x,y,type) {
    var good = false; //no slot found yet
    //run through the list of available objects for an open slot
    for (var ii=0; ii<obj_max; ii++) {
        if (!objectExists(objs[ii])) {
            good=true;
            break;
        }
    }
    //leave if we don't find any
    if (!good) { return; }
    //make the new object, set what it does based on the given type
    objs[ii]=new wb_Object(x,y,0,0); //incomplete object
    switch (type) {
        case "shot":
            objs[ii].sprite=player_shot[0];
            objs[ii].apply=shotApply;
        break;
        case "enemy":
            objs[ii].xd=(x-pf_cx)/6;
            objs[ii].yd=(y-pf_cy)/13;
            objs[ii].subdepth=98;
            objs[ii].depth=3;
            objs[ii].sprite=enemy_spr[3];
            objs[ii].apply=enemyApply;
        break;
        default:
            return;
    }
    objs[ii].type=type;
}
//drawObjects -- draw the objects at a specified depth
//I'm awful and I call it four times lol.
//it works at full speed, but I kind of wish it didn't
function drawObjects(depth) {
    for (var ii=0; ii<obj_max; ii++) {
        if (!objectExists(objs[ii])) {
            continue;
        }
        if (objs[ii].depth == depth) {
            objs[ii].draw();
        }
    }
}

//applyObject -- run the per-frame action for every object
function applyObjects() {
    for (var ii=0; ii<obj_max; ii++) {
        if (!objectExists(objs[ii])) {
            continue;
        }
        objs[ii].apply();
    }
}

//gameKeys -- holds the list of keys held
var gameKeys = {
    up:0,
    down:0,
    left:0,
    right:0,
    action:0,
    bomb:0,
    pause:0
};

//sprites
//player:
var player_maincolor="#08f";
var player_misscolor="#F32";
var player_spr = new wb_Sprite(11,3,5,1,"-d  oxo  b-  )=(M)=(  -p  oxo  q-",player_maincolor);
//player shots:
var player_shot = new Array(4);
player_shot[0] = new wb_Sprite(11,7,5,3,"c    o    c c ooxoo c  oooxxxooo oooxxxxxooo oooxxxooo  c ooxoo c c    o    c","#f80");
player_shot[1] = new wb_Sprite(7,5,3,2,"c  o  c ooxoo ooxxxoo ooxoo c  o  c","#f60");
player_shot[2] = new wb_Sprite(5,3,2,1," ooo oxxxo ooo ","#f40");
player_shot[3] = new wb_Sprite(1,1,0,0,"o","#f20");
//enemies:
var enemy_spr = new Array(4);
enemy_spr[0] = new wb_Sprite(17,7,8,3,"=     m---m     =:: p-w-...-w-q ::  p.....x.....q  -==3-|$xOx$|-E==-  b.....x.....d  :: b-m-...-m-d ::=     w---w     =","#ff8");
enemy_spr[1] = new wb_Sprite(13,5,6,2,"=   m---m   =::pw..x..wq:: -=3-xOx-E=- ::bm..x..md::=   w---w   =","#ee6");
enemy_spr[2] = new wb_Sprite(7,3,3,1,"=:m-m:= 3xoxE =:w-w:=","#dd4");
enemy_spr[3] = new wb_Sprite(3,1,1,0,"3oE","#cc2");


//initialize player object
var player = new wb_Object(40,12,player_spr,0);
player.type="player";
player.xd=0;
player.yd=0;
player.friction=0.25;
player.accel=0.55;
player.max_speed=3;
player.miss=false; //for flashing when the player loses a life

//player.apply -- handle player per-frame actions
player.apply = function() {
    this.x+=this.xd;
    this.y+=this.yd*y_coeff;
    this.xd-=this.friction*Math.sign(this.xd);
    this.yd-=this.friction*Math.sign(this.yd);
    //handle friction
    if (Math.abs(this.xd) < this.friction) { this.xd=0; }
    if (Math.abs(this.yd) < this.friction) { this.yd=0; }
    if (Math.abs(this.xd) > this.max_speed) { this.xd=Math.sign(this.xd)*this.max_speed; }
    if (Math.abs(this.yd) > this.max_speed*y_coeff) { this.yd=Math.sign(this.yd)*this.max_speed*y_coeff; }
    //bounds checking
    if (this.x-this.sprite.cx < 0) {
        this.x=this.sprite.cx;
        this.xd=0;
    }
    if (this.x+(this.sprite.w-this.sprite.cx) > pf_w) {
        this.x=pf_w-(this.sprite.w-this.sprite.cx);
        this.xd=0;
    }
    //bounds checking
    if (this.y-this.sprite.cy < 0) {
        this.y=this.sprite.cy;
        this.yd=0;
    }
    if (this.y+(this.sprite.h-this.sprite.cy) > pf_h) {
        this.y=pf_h-(this.sprite.h-this.sprite.cy);
        this.yd=0;
    }
    if (player.miss) {
        player.sprite.color=player_misscolor;
        player.miss=false;
    } else {
        player.sprite.color=player_maincolor;
    }
};

//doKeyDown -- handle key presses, set key flags
function doKeyDown(event) {
    lastKeyPressed=event.key;
    //stop accidental scrolling
    switch (event.key){
        case "ArrowUp":
        case "ArrowDown":
        case "ArrowLeft": //might remove this one and the one below, they affect alt+left/right
        case "ArrowRight":
            event.preventDefault();
        break;
    }
    //stop key repeats
    if (event.repeat) { return; }
    switch (event.key) {
        //movement
        case "ArrowUp":
            gameKeys.up=1;
        break;
        case "ArrowDown":
            gameKeys.down=1;
        break;
        case "ArrowLeft":
            gameKeys.left=1;
        break;
        case "ArrowRight":
            gameKeys.right=1;
        break;
        //action
        case "q":
        case "a":
        case "z":
            gameKeys.action=1;
        break;
        //bomb
        case "w":
        case "s":
        case "x":
            gameKeys.bomb=1;
        break;
        case "c": //toggle color
            color_on = !color_on;
            //should probably set the view color back to gray here if color is off
        break;
    }
}

//doKeyUp -- handle released keys, unset key flags
function doKeyUp(event) {
    lastKeyReleased=event.key;
    switch (event.key) {
        //movement
        case "ArrowUp":
            gameKeys.up=0;
        break;
        case "ArrowDown":
            gameKeys.down=0;
        break;
        case "ArrowLeft":
            gameKeys.left=0;
        break;progs
        
        case "ArrowRight":
            gameKeys.right=0;
        break;
        //action
        case "q":
        case "a":
        case "z":
            gameKeys.action=0;
        break;
        //action
        case "w":
        case "s":
        case "x":
            gameKeys.bomb=0;
        break;
    }
}

//gd -- get character on display
function gd(x,y) {
	return disp[(x+y*pf_w)];
}
//gd_c -- get color on display
function gd_c(x,y) {
	return disp_col[(x+y*pf_w)];
}

//sd -- set character on display
function sd(x,y,v) {
    if (x < 0 || x >= pf_w || y < 0 || y >= pf_h) { //out of bounds
        return;
    }
    disp_col[(x+y*pf_w)]=fg_color;
	disp[(x+y*pf_w)]=v;
}

//sd_c -- set character and color on display
function sd_c(x,y,v,c) {
    if (x < 0 || x >= pf_w || y < 0 || y >= pf_h) { //out of bounds
        return;
    }
    disp_col[(x+y*pf_w)]=c;
	disp[(x+y*pf_w)]=v;
}

//drawSprite -- draw a text sprite, space is transparent
function drawSprite(x,y,spr) {
    var cc=0;
    x=Math.floor(x); //spent a stupid amount of time forgetting to floor positions with the starfield, was wondering why I couldn't access any elements
    y=Math.floor(y);
    x-=spr.cx; //origin
    y-=spr.cy;
    //plot data to screen buffer
    for (var jj=0; jj < spr.h; jj++) {
        for (var ii=0; ii < spr.w; ii++) {
            if (spr.data.charAt(cc) != " ") {
                sd_c(x+ii,y+jj,spr.data.charAt(cc),spr.color);
            }
            cc++;
        }
    }
}
//

//drawDisp -- clear the display buffer, draw stuff
//used to feel monstrously slow
//now it feels ordinary, but firefox might have issues with constant drawing color changes, I did have issues at one point
function drawDisp() {
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
	//var result_display="";
	for (var jj=0; jj<pf_h; jj++) {
		for (var ii=0; ii<pf_w; ii++) {
            if(color_on) {
                ctx.fillStyle=gd_c(ii,jj);
            }
            
            ctx.fillText(gd(ii,jj),ii*ch_w,(jj+1)*ch_h);
		}
	}
    disp.fill(" "); //clear screen when done
    disp_col.fill(fg_color);
}

//ps -- put a string at a given position
function ps(x,y,to_put) {
    for (var ii=0; ii<to_put.length; ii++) {
        sd(x+ii,y,to_put.charAt(ii));
    }
}

//ps_c -- put a string at a given position in color
function ps_c(x,y,to_put,color) {
    for (var ii=0; ii<to_put.length; ii++) {
        sd_c(x+ii,y,to_put.charAt(ii),color);
    }
}


//getRandomInt -- get an integer between min (inclusive) and max (exclusive)
//taken from https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/random#Getting_a_random_integer_between_two_values
function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min; 
}

//gameTick -- the game loop is here
function gameTick() {
	switch (state) {
		case 0: //titlescreen
            shot_count=0;
            objs.fill("none"); //clear objects
            //todo: clean up
            player.x=40;
            player.y=12;
            player.xd=0;
            player.yd=0;
            ps(0,0,"last score: "+lastscore);
            ps_c(0,2,"this session's top scores:","#fff");
            ps_c(0,3,"* 1st: "+hiscore[0], "#f44");
            ps_c(0,4,"* 2nd: "+hiscore[1], "#f84");
            ps_c(0,5,"* 3rd: "+hiscore[2], "#fc4");
            ps_c(27,12,"WILD-BREAKER.ex by null1024","#88f");
			ps(0,24,"[rev1]")
            ps_c(30,14,"Press Q/A/Z to begin!", "#8f8");
            //todo: add scroller
            if (!color_on) {
                ps(0,24,"Color disabled!");
            }
            //enter game, play music
            if (gameKeys.action > 0) {
                gameKeys.action=2;
                state=1;
                snd_music.volume=0.5;
                snd_music.currentTime=0;
                snd_music.loop=true;
                snd_music.play();
            }
		break;
		case 1: //main game
            //handle player control
            if (gameKeys.up == 1) { player.yd-=player.accel; }
            if (gameKeys.down == 1) { player.yd+=player.accel; }
            if (gameKeys.left == 1) { player.xd-=player.accel; }
            if (gameKeys.right == 1) { player.xd+=player.accel; }
            //handle shooting
            if (gameKeys.action == 1 && shot_count < shot_max) {
                addObject(player.x,player.y,"shot");
                snd_shot.currentTime=0;
                snd_shot.cloneNode(false).play(); //play sound
                shot_count++;
                gameKeys.action=2; //you've already shot with this keypress
            }
            //draw starfield
            for (var kk=0; kk<25; kk++) {
                starfield[kk].applyAndDraw();
            }
            //draw objects -- really disgusting but it works
            //gonna need to adjust it a bit when I rewrite layering
            //maybe -- drawObjects might just do obj.depth % (arg*100)
            drawObjects(3);
            drawObjects(2);
            drawObjects(1);
            drawObjects(0);
            applyObjects(); //deal with everything
            //the player is a special case, handle it:
            player.apply();
            player.draw();
            //spawn new enemies:
            enemy_timer--;
            if (enemy_timer < 0) {
                var exs=Math.random()*8-4;
                var eys=Math.random()*8-4;
                addObject(pf_cx-exs, pf_cy-eys, "enemy");
                enemy_timer=enemy_timer_max;
                enemy_timer_increase--;
                //make game harder
                if (enemy_timer_increase < 0) {
                    if (enemy_timer_max > 14) { //maximum difficulty; todo: move to variable
                        enemy_timer_max--;
                    }
                    enemy_timer_increase=enemy_timer_increase_max;
                }
            }
            score+=1; //increase score for every frame you survive
            //draw hud:
            var hud_text =  "[score]" + score + "[last]"+ lastscore + "[best]" + hiscore[0];
            var hud_text2= "[left]" + lives + "[clock]" + enemy_timer_max;
            ps_c(0,0,hud_text,"#0f8");
            ps_c(0,24,hud_text2,"#f80");
            //cope with dying:
            if (lives < 0) {
                //go to gameover screen
                state=2;
                //set previous and high scores
                prevlastscore=lastscore;
                lastscore=score;
                if (score > hiscore[0]) { //top score
                    hiscore[2]=hiscore[1]; //shift scores over
                    hiscore[1]=hiscore[0];
                    hiscore[0]=score;
                    setScoreMessage("You got the top score!","#ff2");
                } else if (score > hiscore[1]) { //2nd place
                    hiscore[2]=hiscore[1];
                    hiscore[1]=score;
                    setScoreMessage("You got the second best high score!","#4f4");
                } else if (score > hiscore[2]) { //3rd place
                    hiscore[2]=score;
                    setScoreMessage("You got the third best high score!","#2ff");
                } else { //out of score ranking
                    setScoreMessage("rank out...","#565");
                }
            }
		break;
		case 2: //game over, show current and best score here, display endings (todo)
            snd_music.pause();
            snd_music.currentTime=0;
            //todo: fix score messaging, it's broken
            ps_c(0,0,"G A M E   O V E R !", "#F44");
            ps_c(0,1,score_message,score_message_color);
            //todo: adjust spacing
            ps(0,2,"This run's score: "+score);
            ps(0,3,"Highest score: "+hiscore[0]);
            ps(0,4,"Previous run's score: "+prevlastscore);
            ps(0,5,"Hold Q, A, or Z to continue...");
            //return to title when fire is held:
            if (gameKeys.action > 0) {
                gameKeys.action++;
                if (gameKeys.action > 8) {
                    gameInit(); //sets the state too
                    gameKeys.action=0;
                }
            }
		break;
        case 3: //pause
            ps(0,0,"game paused");
            if (gameKeys.pause==1) {
                gameKeys.pause=2;
                state=1;
            }
        break;
        case -1: //key test
            ps(35,0,"[KEY TEST]");
            ps(0,1,"Key pressed: " + lastKeyPressed);
            ps(0,2,"Key released: " + lastKeyReleased);
            ps(0,4,"Pressing up? " + gameKeys.up);
            ps(0,5,"Pressing down? " + gameKeys.down);
            ps(0,6,"Pressing left? " + gameKeys.left);
            ps(0,7,"Pressing right? " + gameKeys.right);
            ps(0,8,"Pressing action (fire)? " + gameKeys.action);
            ps(0,9,"Pressing bomb? " + gameKeys.bomb);
            ps(0,pf_h-2,"//WILD-BREAKER.ex input debug mode");
            ps(0,pf_h-1,"//2017 null1024");
        break;
	}
    window.setTimeout(gameTick,32);
    //window.requestAnimationFrame(gameTick); //really do want to use this, loads would need changing and I really need to figure out how to handle not 60hz displays -- delta time seems like a total mess for a heavily score-based game like this, you could do a fair bit worse or better just based on what monitor you have plugged in with no change in playing ability and I hate that
	drawDisp();
}

//reset everything to defaults when starting a new game
//todo: completely consolidate the spread-out game restart process here, I think there's a few little holdouts
function gameInit() {
    lives=2;
    bombs=3;
    score=0;
    state=0;
    enemy_timer_max=35;
    enemy_timer_increase_max=5
    enemy_timer_increase=enemy_timer_increase_max;
    enemy_timer=enemy_timer_max;
}

//start the game after everything's good and ready
window.onload = function() {
    //starfield
    for (var nn=0; nn<25; nn++) {
        starfield[nn]=new wb_Star();
    }
    //setup inputs
    window.addEventListener("keydown", doKeyDown);
    window.addEventListener("keyup", doKeyUp);
    //setup sfx, music
    snd_shot=document.getElementById("sndshot");
    snd_explosion=document.getElementById("sndexplosion");
    snd_enemyshot=document.getElementById("sndenemyshot");
    snd_music=document.getElementById("sndmusic");
    //setup display
    c=document.getElementById("gamecanvas");
    ctx=c.getContext("2d");
    ctx.font=disp_font;
    ch_w=ctx.measureText("x").width;
    ctx.canvas.width=ch_w*pf_w;
    ctx.canvas.height=ch_h*pf_h+6; //slight offset needed, text gets clipped off otherwise
    ctx.font=disp_font; //font needs to be set before (to measure it) and after resizing the canvas (because it gets reset)
    ctx.fillStyle=fg_color;
    disp.fill("!"); //clear screen
    disp_col.fill(fg_color); //set default color
    gameInit(); //set game variables up
	gameTick(); //this call kicks the game off
}