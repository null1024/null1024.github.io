WILD-BREAKER.ex [rev1] is not nearly as enhanced as I'd wanted, but I don't know if I'm ever going to sit down and finish. This was supposed to be done back in 2017, and it's 2022 now.
I've cleaned things up enough that it's good enough to release, however.

The contents of story.txt represent the planned story, many of the other .txt files are the graphics I was designing with JavE.

game-ex.html is the game itself, readme-ex.html has how-to-play and other information.

Have fun!
--null1024