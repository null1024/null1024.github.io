the deep motion -- (C)2014 null1024
This project is distributed under CC BY-NC-SA 4.0.
See <https://creativecommons.org/licenses/by-nc-sa/4.0/> for more details.
Graphics, sound, and game code are all by me.

This is a short two level release of a shoot-em-up game with mouse aiming that I was working on.

I made this back in 2014 in Game Maker 5.3a, which was already really showing its age at that point.
I was going to modify it for later versions of Game Maker, but I kind of just decided to drop the project.
.GMD source is included if you want to check it out or maybe attempt the conversion yourself. The project is CC licensed, so as long as you don't sell it, keep the same license, and give credit, you can do whatever you want with the graphics, sound, or game code.

GM5.3 games have performance issues running on Windows 8 and up.
It wouldn't actually be too hard to update it for a more modern Game Maker release, which would also solve any performance issues, I just haven't done it.

Controls:
* mouse: aim
* W/A/S/D: movement
* tab, right click: bomb (3 per life)
* space, left click: fire
* esc: exit game immediately
* f1: show help
* f4: toggle fullscreen
* shift: slow down movement (hold)

Hope you enjoy.